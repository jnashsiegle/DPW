#used as a playground to test/debug bits of the program at a time
name = raw_input ("What is your name?  ")  #get player name for use within game
friend = raw_input("What is your favorite name, " +name +"? ") #lets add a name for the family pet
best_friend = raw_input ("Please choose a number between 1-5, thank you " + name + ".  ")

players = ["Mike", "John", "Chris", "Larry", "Moe"]  #and some friends or students or pets, it's a name pool

z = int(best_friend)
print players[z]




'''
Jana Nash-Siegle
Testing and debugging file
'''