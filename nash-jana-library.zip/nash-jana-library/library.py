"""created by Jana Nash-Siegle
DPW 101501
Wainman
10/14/2015
"""

class UserInfo(object):
	pass

class BudgetBreak(object):
	pass